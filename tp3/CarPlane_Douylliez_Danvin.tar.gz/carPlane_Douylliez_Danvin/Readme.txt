Douylliez maxime
Danvin florian
Je tiens à m'excuser pour le rendu2 que je n'ai pas fait. J'ai fait le tp en retard suite une grosse démotivation en début de semestre. le tp2 complet est joint dans cette archive en plus du 3. 

L'ensemble du tp à été fait sauf la derniere question. J'ai passé trop de temps sur le déplacement de la voiture,( avancer dans la bonne direction alors qu'elle tourne), et j'ai eu beaucoup de mal a placer la camera deriere l'avion et faire en sorte qu'elle y reste (utilisation d'un translate).

J'ai encore beaucoup de mal avec l'orientation qui modifie la position, forcément.

Le tp a été long pour moi, a cause de deux endroits ou j'ai bloqué, et j'aurais du demander un coup de pouce à ces moments la !


