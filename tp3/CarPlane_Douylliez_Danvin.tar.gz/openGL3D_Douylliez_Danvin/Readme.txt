douylliez maxime
danvin florian

Doit contenir :
- ce que vous avez fait.
L'ensemble du tp a été réalisé, je tiens à m'excuser pour le retard, il est du a une grosse démotivation en début de semestre, mais je suis motivé pour reprendre de plus belle !

- ce que vous n'avez pas fait (et pourquoi).
la question bonus n'as pa été faite, j'ai eu l'idée d'utiliser sinus et cosinus pour deplacer la source de lumiere en fonction du degré mais je n'ais pas reussi a le faire fonctionner.



- difficultés rencontrées.
j'ai eu BEAUCOUP de mal dans les premieres questions avec la manipulation de setOrtho et les fonctions de comparaisons greater et less.

- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 
la longueur du sujet etait bonne, et l'on comprend de mieux en mieux !
