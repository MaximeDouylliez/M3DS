Douylliez maxime
Danvin florian

Je n'ais pas travaillé avec le binome indiqué dans les archives, mais je l'ai laissé pour respecter les conventions de nomages.

Winged à été fait jusqu'a la question bonus.

J'ai eu BEAUCOUP de difficulté à appliquer le principe de wingedFace mais une fois comprise le reste s'est passé tout seul !
