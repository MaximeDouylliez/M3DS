Douylliez Maxime
Danvin Florian

Je n'ais pas travaillé avec le binome indiqué dans les archives, mais je l'ai laissé pour respecter les conventions de nomages.

j'ai travaillé en collaboration a partir de la question 1 de l'exercice 4 avec erwan douaille et rémy, et on a oublié de faire le commit. 

Le tp en l'état, seule deux questions on été faite, 3 autre questions sonts sur une machine a l'université. 

j'ai littérallement bloqué plusieurs heures sur la question 2, on a eu aussi pas mal de difficulté sur le face cutting. 
