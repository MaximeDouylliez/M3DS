Douylliez maxime

Doit contenir :
- ce que vous avez fait.
Le tp à été réalisé jusqu'a la toute derniere question non incluse.

- ce que vous n'avez pas fait (et pourquoi).
Je n'ai pas reussi a faire la toute derniere question, la vue se déplace bizarement.
 
- difficultés rencontrées.
j'ai voulu utiliser des fonctions dans hermite pour faire les calculs et je me suis perdu, du coup j'ai refait une partie des calculs a la main et c'est plus clair !
j'ai eu du mal sur l'implem des courbes de bezier avec De Casteljau


- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 
Le tp était plus cours que les précedents, enfin la partie BSP du tp précedent n'etait pas simple alors ca fait contraste !
